JJROBOTS B-ROBOT
=================
Self Balancing Arduino robot. Control via Smartphone/Tablet. Fully 3D printed parts.
New: This new version include support for the new V2 board! (with integrated ESP wifi module)

All the documentation, features, how it works, build manuals and SHOP here:
URL: http://jjrobots.com/b-robot

This is the new and improved version of this old project:
Blog: http://cienciaycacharreo.blogspot.com.es/2013/10/b-robot-un-robot-equilibrista-impreso_28.html

To install code read the install.txt instructions

JJROBOTS 2015. Science & fun!
       
      
